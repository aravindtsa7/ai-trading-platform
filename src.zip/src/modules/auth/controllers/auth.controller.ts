import { Request, Response, NextFunction } from "express";
import { AuthService } from "../services/AuthService";
import { ApiResponse } from "../../../common/responses/ApiResponse";

export class AuthController {
  constructor(private readonly authService: AuthService) {}

  register = async (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    try {
      const user = await this.authService.register(req.body);

      return ApiResponse.success(res, {
        message: "User registered successfully",
        statusCode: 201,
        data: {
          id: user.id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phone: user.phone,
          role: user.role,
          status: user.status,
        },
      });
    } catch (error) {
      next(error);
    }
  };
}